﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MyWindowsService
{
    public static class LogHelper
    {
        #region 日志

        private static string filePath = @"D:\MyServiceLog.txt";
        public static void WriteLog(string msg, string action = "")
        {
            using (FileStream stream = new FileStream(filePath, FileMode.Append))
            using (StreamWriter writer = new StreamWriter(stream))
            {
                writer.WriteLine($"【{DateTime.Now}】 {action} --- {msg}");
            }
        }

        #endregion
    }
}
