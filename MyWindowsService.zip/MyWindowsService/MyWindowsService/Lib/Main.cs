﻿using MQSDK;
using MQSDK.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MyWindowsService
{
    public class Main
    {

        //MqHandler mqHandler = new MqHandler();
        public void Start()
        {
            // mqHandler.CreateClient();

            LogHelper.WriteLog("Main.Load，服务已启动");
        }

        public void Stop()
        {
            // mqHandler.CreateClient();

            LogHelper.WriteLog("Main.Stop，服务已停止");
        }




    }
}
