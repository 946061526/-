﻿using MQSDK;
using MQSDK.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyWindowsService
{
    /// <summary>
    /// MQ操作类
    /// </summary>
    public class MqHandler
    {
        MQSDK.IMQSdk mqClient;
        private string _queueManagerName = "";
        private string _queueName = "";
        private string _dataChannel = "";

        /// <summary>
        /// 创建MQ实例
        /// </summary>
        public void CreateClient()
        {
            this.mqClient = MQSDK.SdkClient.Create();

            if (Connect(_queueManagerName))//连接成功
            {
                LogHelper.WriteLog("MQ连接成功", "CreateClient");


            }
            else
            {
                LogHelper.WriteLog("MQ连接失败", "CreateClient");
            }
        }

        /// <summary>
        /// MQ连接
        /// </summary>
        /// <param name="mqName"></param>
        public bool Connect(string queueManagerName)
        {
            var response = this.mqClient.Connect(queueManagerName);
            //WriteLog("connect", response);
            if (response.IsSuccessful) // 连接成功
            {
                //
                return true;
            }
            return false;
        }

        /// <summary>
        /// MQ断开连接
        /// </summary>
        public void DisConnect()
        {
            var response = this.mqClient.Disconnect();
            if (response.IsSuccessful)
            {
                //
            }
        }

        /// <summary>
        /// 监听队列
        /// </summary>
        /// <param name="queueManagerName">队列管理器名称</param>
        /// <param name="queueName">队列名称</param>
        /// <param name="onReceived">消息处理方法（可选）可通过事件订阅</param>
        /// <param name="onStoped">监听停止处理方法（可选）可通过事件订阅</param>
        /// <returns><see cref="SdkResponseBase"></see></returns>
        public void Listien(string queueManagerName, string queueName, ReceivedHandler onReceived = null, ListenStopedHandler onStoped = null)
        {
            var response = mqClient.Listen(queueManagerName, queueName,
                onReceived: (msgId, msg) =>
                {
                    // TODO:: 消息处理

                    LogHelper.WriteLog($"收到消息：msgId={msgId} & msg={msg}", "Listien");
                },
                onStoped: (qMgrName, qName) =>
                {
                    //TODO::监听停止

                });
            if (response.IsSuccessful)
            {
                // TODO:: Success
            }
            else
            {
                // TODO:: Failure
            }
        }

        /// <summary>
        /// 停止监听
        /// </summary>
        public void Stop()
        {
            var response = mqClient.Stop();
            if (response.IsSuccessful)
            {
                // TODO:: Success
            }
            else
            {
                // TODO:: Failure
            }
        }

        /// <summary>
        /// 推送消息
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="dataChannel"></param>
        public void Push(string msg, string msgId, string dataChannel = null)
        {
            SdkResponse<PutMsgResult> response = new SdkResponse<PutMsgResult>() { IsSuccessful = false };
            if (!string.IsNullOrEmpty(msgId))
            {
                response = this.mqClient.PutMsgWithId(msgId, msg, dataChannel);
            }
            else
            {
                response = this.mqClient.PutMsg(msg, dataChannel);
            }
            //WriteLog("putMsg", response);
            if (response.IsSuccessful)
            {
                //this.txtPutMsgId.Text = response.Result.MessageId;


                LogHelper.WriteLog($"推送消息成功：msgId={msgId} & msg={msg} & dataChannel={dataChannel}", "Push");
            };
        }

        /// <summary>
        /// 获取消息
        /// </summary>
        /// <param name="dataChannel"></param>
        /// <param name="msgId"></param>
        /// <param name="waitInterval">获取超时等待时间（毫秒）</param>
        public void GetMsg(string dataChannel, string msgId = "", uint waitInterval = 3000)
        {
            SdkResponse<GetMsgResult> response = new SdkResponse<GetMsgResult>() { IsSuccessful = false };
            if (!string.IsNullOrEmpty(msgId))
            {
                response = this.mqClient.GetMsgById(msgId, waitInterval, dataChannel);
            }
            else
            {
                response = this.mqClient.GetMsg(waitInterval, dataChannel);
            }
            if (response.IsSuccessful)
            {
                //
                LogHelper.WriteLog($"推送消息成功：msgId={msgId} & waitInterval={waitInterval} & dataChannel={dataChannel}", "GetMsg");
            }
            else
            {
                //
            }
        }

    }
}
